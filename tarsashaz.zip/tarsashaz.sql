-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 04, 2023 at 10:59 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tarsashaz`
--
CREATE DATABASE IF NOT EXISTS `tarsashaz` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `tarsashaz`;

-- --------------------------------------------------------

--
-- Table structure for table `forgalom`
--

DROP TABLE IF EXISTS `forgalom`;
CREATE TABLE IF NOT EXISTS `forgalom` (
  `forgalomkod` int(11) NOT NULL AUTO_INCREMENT,
  `tipuskod` int(11) DEFAULT NULL,
  `nevkod` int(11) DEFAULT NULL,
  `osszeg` decimal(10,2) DEFAULT NULL,
  `bank` tinyint(1) DEFAULT NULL,
  `datum` date DEFAULT NULL,
  PRIMARY KEY (`forgalomkod`),
  KEY `forgalom_tipus_tipuskod_fk` (`tipuskod`),
  KEY `forgalom_ugyfel_ugyfelkod_fk` (`nevkod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `forgalom`:
--   `tipuskod`
--       `tipus` -> `tipuskod`
--   `nevkod`
--       `ugyfel` -> `ugyfelkod`
--

-- --------------------------------------------------------

--
-- Table structure for table `ingatlan`
--

DROP TABLE IF EXISTS `ingatlan`;
CREATE TABLE IF NOT EXISTS `ingatlan` (
  `ingatlankod` int(11) NOT NULL AUTO_INCREMENT,
  `tulajdonoskod` int(11) DEFAULT NULL,
  `lakas` varchar(5) DEFAULT NULL,
  `nyito` decimal(10,2) DEFAULT NULL,
  `kozos` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`ingatlankod`),
  KEY `ingatlan_ugyfel_ugyfelkod_fk` (`tulajdonoskod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `ingatlan`:
--   `tulajdonoskod`
--       `ugyfel` -> `ugyfelkod`
--

-- --------------------------------------------------------

--
-- Table structure for table `tipus`
--

DROP TABLE IF EXISTS `tipus`;
CREATE TABLE IF NOT EXISTS `tipus` (
  `tipuskod` int(11) NOT NULL AUTO_INCREMENT,
  `megnevezes` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`tipuskod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `tipus`:
--

-- --------------------------------------------------------

--
-- Table structure for table `ugyfel`
--

DROP TABLE IF EXISTS `ugyfel`;
CREATE TABLE IF NOT EXISTS `ugyfel` (
  `ugyfelkod` int(11) NOT NULL AUTO_INCREMENT,
  `megnevezes` varchar(50) DEFAULT NULL,
  `telefon` varchar(12) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ugyfelkod`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `ugyfel`:
--

--
-- Dumping data for table `ugyfel`
--

INSERT INTO `ugyfel` (`ugyfelkod`, `megnevezes`, `telefon`, `email`) VALUES
(1, 'Kovacs Sandor', '06208569874', 'sanyika123@gmail.com'),
(2, 'Toth Jozsef', '06308553214', 'jocika44@ukraine.me');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `forgalom`
--
ALTER TABLE `forgalom`
  ADD CONSTRAINT `forgalom_tipus_tipuskod_fk` FOREIGN KEY (`tipuskod`) REFERENCES `tipus` (`tipuskod`),
  ADD CONSTRAINT `forgalom_ugyfel_ugyfelkod_fk` FOREIGN KEY (`nevkod`) REFERENCES `ugyfel` (`ugyfelkod`);

--
-- Constraints for table `ingatlan`
--
ALTER TABLE `ingatlan`
  ADD CONSTRAINT `ingatlan_ugyfel_ugyfelkod_fk` FOREIGN KEY (`tulajdonoskod`) REFERENCES `ugyfel` (`ugyfelkod`);


--
-- Metadata
--
USE `phpmyadmin`;

--
-- Metadata for table forgalom
--

--
-- Metadata for table ingatlan
--

--
-- Metadata for table tipus
--

--
-- Metadata for table ugyfel
--

--
-- Metadata for database tarsashaz
--
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
