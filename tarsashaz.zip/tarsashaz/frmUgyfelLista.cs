﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;


namespace tarsashaz
{
    public partial class frmUgyfelLista : Form
    {
        MySqlConnection Conn;
        public frmUgyfelLista()
        {
            InitializeComponent();
        }

        void Lekerdez()
        {
            Conn = Connect.InitDB();
            String sql = $"SELECT `ugyfelkod`, `megnevezes`, `telefon`, `email` FROM `ugyfel` WHERE `megnevezes` like '%{textBox2.Text}%' and `telefon` like '%{textBox3.Text}%';";
            MySqlCommand cmd = new MySqlCommand(sql, Conn);
            MySqlDataReader reader = cmd.ExecuteReader();
            dataGridView1.Columns.Clear();
            dataGridView1.Rows.Clear();
            dataGridView1.Columns.Add("ugyfelkod", "Kod");
            dataGridView1.Columns.Add("megnevezes", "Nev");
            dataGridView1.Columns.Add("telefon", "telefon");
            dataGridView1.Columns.Add("email", "email");
            while (reader.Read())
            {
                dataGridView1.Rows.Add(
                    new object[]
                    {
                        reader["ugyfelkod"].ToString(),
                        reader["megnevezes"].ToString(),
                        reader["telefon"].ToString(),
                        reader["email"].ToString(),
                    });
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            Lekerdez();
            if (textBox2.Text == "" && textBox3.Text == "") { dataGridView1.Columns.Clear(); dataGridView1.Rows.Clear(); }
            Conn.Close();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            Lekerdez();
            if (textBox2.Text == "" && textBox3.Text == "") { dataGridView1.Columns.Clear(); dataGridView1.Rows.Clear(); }
            Conn.Close();
        }
    }
}
