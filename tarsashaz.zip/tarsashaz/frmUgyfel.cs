﻿using System;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace tarsashaz
{
    public partial class frmUgyfel : Form
    {
        MySqlConnection conn;
        public frmUgyfel()
        {
            InitializeComponent();
            conn = Connect.InitDB();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            frmUgyfelLista frmul = new frmUgyfelLista();
            frmul.Show();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = "INSERT INTO ugyfel (megnevezes, telefon, email) VALUES ('" + textBox2.Text + "', '" + textBox3.Text + "', '" + textBox4.Text + "')";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Sikeresen hozzáadva!", "Ügyfél hozzáadása", MessageBoxButtons.OK, MessageBoxIcon.Information);
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
            } catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void frmUgyfel_Load(object sender, EventArgs e)
        {

        }
    }
}
