﻿using System;
using System.Windows.Forms;

namespace tarsashaz
{
    public partial class frmMain : Form
    {
        DateTime dt;
        public frmMain()
        {
            InitializeComponent();
            dt = DateTime.Now;
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            label2.Text = dt.ToString("yyyy. MMMM dd.");
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            contextMenuStrip1.Show(Cursor.Position);
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmUgyfel frmu = new frmUgyfel();
            frmu.Show();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            frmUgyfelLista frmul = new frmUgyfelLista();
            frmul.Show();
        }
    }
}
